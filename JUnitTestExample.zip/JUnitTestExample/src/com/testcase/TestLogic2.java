package com.testcase;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.logic.Admin;

public class TestLogic2 {
	
	@Test
	public void testEmailValidation() {
		
		/*if(assertEquals(0,Admin.validateEmail("uma123@gmail.com")))
			
			result="success";
		else
			result="fail";
		return result;*/
		assertEquals(1,Admin.validateEmail("uma123gmail.com"));
		
	}

}
